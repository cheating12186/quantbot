"""FastAPI package for QuantPilot."""
